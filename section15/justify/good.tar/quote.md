c is    quirky,     flawed,     and an
enormous    success.        Although accidents of   history
  surely helped,     it evidently    satisfied   a   need

    for a   system implementation   language    efficident
 enough to   displace       assembly language,
    yet sufficiently abstract and fluent    to describe
algorithms and      interactions in a   wide    variety
of environments.
                            --              Dennis      M.          Ritchie